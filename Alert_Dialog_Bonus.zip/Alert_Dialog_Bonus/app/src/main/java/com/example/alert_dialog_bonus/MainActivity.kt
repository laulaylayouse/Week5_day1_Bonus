package com.example.alert_dialog_bonus

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import kotlinx.android.synthetic.main.activity_main_3.view.*

class MainActivity : AppCompatActivity() {

    lateinit var Button_Show: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        Button_Show = findViewById(R.id.Button_Show)
        Button_Show.setOnClickListener {

            val builder = AlertDialog.Builder(this)
            val dialogView = LayoutInflater.from(this).inflate(R.layout.activity_main_3, null)
            builder.setView(dialogView)

            dialogView.Button_TV.setOnClickListener {
                dialogView.Text_View.text= dialogView.Edit_Text.text
                dialogView.Edit_Text.setText("")
            }
            dialogView.Button_Go.setOnClickListener {
                val intent= Intent(this,MainActivity2::class.java)
                Toast.makeText(this,dialogView.Text_View.text,Toast.LENGTH_SHORT).show()
                intent.putExtra("textView",dialogView.Text_View.text.toString())
                startActivity(intent)
            }
            val alert: AlertDialog = builder.create()

            alert.setCancelable(true)
            alert.show()
        }
    }
}