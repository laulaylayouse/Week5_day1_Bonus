package com.example.alert_dialog_bonus

import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity2 : AppCompatActivity() {

    lateinit var textView: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_2)

        textView = findViewById(R.id.textView)

        val text=intent.getStringExtra("textView").toString()
        Toast.makeText(this,text, Toast.LENGTH_SHORT).show()
        textView.setText(text)
    }
}