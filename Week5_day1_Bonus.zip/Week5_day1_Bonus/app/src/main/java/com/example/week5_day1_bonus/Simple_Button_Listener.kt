package com.example.week5_day1_bonus

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class Simple_Button_Listener : AppCompatActivity() {

    lateinit var button: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.simple_button_listener_activity)

        button=findViewById(R.id.Button1)
        button.setOnClickListener {
            Toast.makeText(this,"CODE",Toast.LENGTH_SHORT).show()
        }
    }
    fun XML(view: View){
        Toast.makeText(this,"XML",Toast.LENGTH_SHORT).show()
    }
}