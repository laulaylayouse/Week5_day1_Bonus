package com.example.week5_day1_bonus

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class three_buttons_2 : AppCompatActivity() {

    lateinit var TextView: TextView
    lateinit var Button_Back: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.three_buttons_2)

        TextView = findViewById(R.id.TextView)
        Button_Back=findViewById(R.id.Button_Back)

        val intent=getIntent()
        val text= intent.getStringExtra("TextView")

        TextView.setText(text)
        Button_Back.setOnClickListener {
            val intent = Intent(this, three_buttons::class.java)
            startActivity(intent)
        }
    }
}