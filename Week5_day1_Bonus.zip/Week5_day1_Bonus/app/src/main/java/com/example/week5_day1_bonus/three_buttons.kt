package com.example.week5_day1_bonus

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class three_buttons : AppCompatActivity() {

    lateinit var EditText_Toast: EditText
    lateinit var EditText_Update: EditText
    lateinit var EditText_NewActivity: EditText
    lateinit var Button_Toast: Button
    lateinit var Button_Update: Button
    lateinit var Button_NewActivity: Button
    lateinit var TextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.three_buttons_1)

        EditText_Toast = findViewById(R.id.EditText_Toast)
        EditText_Update = findViewById(R.id.EditText_Update)
        EditText_NewActivity = findViewById(R.id.EditText_NewActivity)
        Button_Toast = findViewById(R.id.Button_Toast)
        Button_Update = findViewById(R.id.Button_Update)
        Button_NewActivity = findViewById(R.id.Button_NewActivity)
        TextView = findViewById(R.id.TextView)

        Button_Toast.setOnClickListener {
            Toast.makeText(this, EditText_Toast.text.toString(), Toast.LENGTH_SHORT).show()
            EditText_Toast.setText("")
        }
        Button_Update.setOnClickListener {
            TextView.text = EditText_Update.text
            EditText_Update.setText("")
        }
        Button_NewActivity.setOnClickListener {

            val intent = Intent(this, three_buttons_2::class.java)
            intent.putExtra("TextView", EditText_NewActivity.text.toString())
            startActivity(intent)
            EditText_NewActivity.setText("")
        }
    }
}