package com.example.week5_day1_bonus

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity

class MenuApp_3 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.menu_app_3_activity)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_app_menu, menu)
        return true
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            R.id.MenuApp -> {
                val intent= Intent(this,MenuApp::class.java)
                startActivity(intent)
                return true
            }
            R.id.MenuApp_1 -> {
                val intent= Intent(this,MenuApp_1::class.java)
                startActivity(intent)
                return true
            }
            R.id.MenuApp_2 -> {
                val intent= Intent(this,MenuApp_2::class.java)
                startActivity(intent)
                return true
            }
            R.id.MenuApp_3 -> {
                val intent= Intent(this,MenuApp_3::class.java)
                startActivity(intent)
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }
}