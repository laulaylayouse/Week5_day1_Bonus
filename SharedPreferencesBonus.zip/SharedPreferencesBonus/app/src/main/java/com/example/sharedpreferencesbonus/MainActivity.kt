package com.example.sharedpreferencesbonus

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText

class MainActivity : AppCompatActivity() {

    lateinit var EditText_Intent: EditText
    lateinit var EditText_Shared: EditText

    lateinit var Button_Intent: Button
    lateinit var Button_Shared: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        EditText_Intent =findViewById(R.id.EditText_Intent)
        EditText_Shared=findViewById(R.id.EditText_Shared)

        Button_Intent=findViewById(R.id.Button_Intent)
        Button_Shared = findViewById(R.id.Button_Shared)

        Button_Intent.setOnClickListener{
            val intent= Intent(this,MainActivity2::class.java)
            intent.putExtra("IntentData", EditText_Intent.text.toString())
            EditText_Intent.setText("")
            startActivity(intent)

        }
        Button_Shared.setOnClickListener {
            var sharedPreferences= this.getSharedPreferences("TextView", Context.MODE_PRIVATE)

            with(sharedPreferences.edit()) {
                putString("Data",EditText_Shared.text.toString() )
                apply()
            }
        }
    }
}