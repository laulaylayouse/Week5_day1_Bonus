package com.example.sharedpreferencesbonus

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class MainActivity2 : AppCompatActivity() {

    lateinit var TextView_Intent: TextView
    lateinit var TextView_Shared: TextView
    lateinit var Button_Shared: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        TextView_Intent = findViewById(R.id.TextView_Intent)
        TextView_Shared = findViewById(R.id.TextView_Shared)

        Button_Shared = findViewById(R.id.Button_Shared)

        TextView_Intent.setText(intent.getStringExtra("IntentData"))
        Button_Shared.setOnClickListener {

            val sharedPreferences = this.getSharedPreferences("TextView", Context.MODE_PRIVATE)
            TextView_Shared.setText( sharedPreferences.getString("Data",""))
        }

    }
}